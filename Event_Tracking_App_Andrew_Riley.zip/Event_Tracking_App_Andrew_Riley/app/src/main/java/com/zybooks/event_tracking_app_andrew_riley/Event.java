package com.zybooks.event_tracking_app_andrew_riley;

public class Event {
    private int mId;
    private String mEventName;
    private String mDate;
    private String mDescription;

    public Event() {
    }
    public Event(int id, String eventName, String date, String description) {
        this.mId = id;
        this.mEventName = eventName;
        this.mDate = date;
        this.mDescription = description;
    }

    public int getId() {
        return mId;
    }

    public void setId(int id) {
        mId = id;
    }

    public String getEventName() {
        return mEventName;
    }

    public void setEventName(String eventName) {
        mEventName = eventName;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String description) {
        mDescription = description;
    }
}
