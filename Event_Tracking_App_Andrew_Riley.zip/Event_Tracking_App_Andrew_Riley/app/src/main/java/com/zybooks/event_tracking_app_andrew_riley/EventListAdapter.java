package com.zybooks.event_tracking_app_andrew_riley;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class EventListAdapter extends ArrayAdapter<Event> {

    private Context context;
    private int resource;

    public EventListAdapter(Context context, int resource, List<Event> events) {
        super(context, resource, events);
        this.context = context;
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listEvent = convertView;

        if (listEvent == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            listEvent = inflater.inflate(resource, null);
        }

        Event currentEvent = getItem(position);

        if (currentEvent != null) {
            TextView eventName = listEvent.findViewById(R.id.textViewEventName);
            TextView date = listEvent.findViewById(R.id.textViewDate);
            TextView description = listEvent.findViewById(R.id.textViewDescription);

            eventName.setText(currentEvent.getEventName());
            date.setText(currentEvent.getDate());
            description.setText(currentEvent.getDescription());
        }

        return listEvent;
    }
}
