package com.zybooks.event_tracking_app_andrew_riley;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class EventListActivity extends AppCompatActivity {

    private ListView eventListView;
    private ImageButton addEventButton, smsButton, deleteAllEventsButton;
    private EventDatabase eventDatabase;
    private EventListAdapter eventListAdapter;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        setContentView(R.layout.activity_event_list);

       eventListView = findViewById(R.id.eventListView);
       addEventButton = findViewById(R.id.addEventButton);
       smsButton = findViewById(R.id.smsButton);
       deleteAllEventsButton = findViewById(R.id.deleteAllEventsButton);
       eventDatabase = new EventDatabase(this);
       eventListAdapter = new EventListAdapter(this, R.layout.activity_event_list, eventDatabase.getEvents());
       eventListView.setAdapter(eventListAdapter);

       checkEmptyList();

       addEventButton.setOnClickListener(view -> {
           Intent intent = new Intent(EventListActivity.this, AddEventActivity.class);
           startActivity(intent);
       });

       deleteAllEventsButton.setOnClickListener(view -> {
           EventDatabase evDatabase = new EventDatabase(this);
           evDatabase.deleteAllEvents();

           eventListAdapter.clear();
           eventListAdapter.notifyDataSetChanged();
       });
    }

    private void checkEmptyList() {
        if (eventListAdapter.isEmpty()) {
            findViewById(R.id.emptyView).setVisibility(View.VISIBLE);
        }
        else {
            findViewById(R.id.emptyView).setVisibility(View.GONE);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateEventList();
    }

    private void updateEventList() {
        List<Event> eventList = eventDatabase.getEvents();
        eventListAdapter.clear();
        eventListAdapter.addAll(eventList);
        eventListAdapter.notifyDataSetChanged();

        checkEmptyList();
    }

    public void onSmsButtonClick(View view) {
        if (checkSmsPermission()) {
            Toast.makeText(this, "SMS notifications already turned on", Toast.LENGTH_SHORT).show();
        }
        else {
            requestSmsPermission();
        }
    }

    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        }
    }

    public void onRequestPermissionResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Permission denied, cannot enable SMS notifications", Toast.LENGTH_SHORT).show();
            }
        }
    }

}