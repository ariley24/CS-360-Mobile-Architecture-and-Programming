package com.zybooks.event_tracking_app_andrew_riley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class EventDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "eventTrackingDatabase";
    private static final int DATABASE_VERSION = 2;

    // Users table
    private static final String TABLE_NAME_USERS = "Users";
    private static final String COLUMN_ID_USERS = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Events Table
    private static final String TABLE_NAME_EVENTS = "Events";
    private static final String COLUMN_ID_EVENTS = "id";
    private static final String COLUMN_EVENT_NAME = "eventName";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_DESCR = "description";

    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_NAME_USERS + " (" +
                    COLUMN_ID_USERS + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT);";

    private static final String CREATE_TABLE_EVENTS =
            "CREATE TABLE " + TABLE_NAME_EVENTS + " (" +
                    COLUMN_ID_EVENTS + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EVENT_NAME + " TEXT, " + COLUMN_DATE + " TEXT, " +
                    COLUMN_DESCR + " TEXT);";

    public EventDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_EVENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_EVENTS);
        onCreate(db);
    }

    // Insert data into Users table
    public long insertUserData(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_NAME_USERS, null, values);
        db.close();
        return result;
    }

    // Checks for existing user in database
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID_USERS};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_NAME_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public long insertEvent(String eventName, String date, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_DESCR,description);
        long result = db.insert(TABLE_NAME_EVENTS, null, values);
        db.close();
        return result;
    }

    public Cursor getEventById(long eventId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {"id", "eventName", "date", "description"};
        String selection = "id = ?";
        String[] selectionArgs = {String.valueOf(eventId)};

        return db.query(TABLE_NAME_EVENTS, projection, selection, selectionArgs, null, null, null);
    }

    public int editEvent(int id, String eventName, String date, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, eventName);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_DESCR, description);
        return db.update(TABLE_NAME_EVENTS, values, COLUMN_ID_EVENTS + "=?", new String[]{String.valueOf(id)});
    }

    public List<Event> getEvents() {
        List<Event> eventList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME_EVENTS, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID_EVENTS));
                String eventName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EVENT_NAME));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE));
                String description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCR));

                Event event = new Event(id, eventName, date, description);
                eventList.add(event);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return eventList;
    }

    public void deleteAllEvents() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME_EVENTS, null, null);
        db.close();
    }
}