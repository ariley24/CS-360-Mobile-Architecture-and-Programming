package com.zybooks.event_tracking_app_andrew_riley;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {

    private EditText editTextEventName, editTextEventDate, editTextEventDescription;
    private Button cancelButton, addEventButton;
    private EventDatabase eventDatabase;
    private long eventId= -1;
    private static final String KEY_EVENT_ID = "eventId";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDate = findViewById(R.id.editTextEventDate);
        editTextEventDescription = findViewById(R.id.editTextEventDescription);
        cancelButton = findViewById(R.id.cancelButton);
        addEventButton = findViewById(R.id.addEventButton);
        eventDatabase = new EventDatabase(this);

        Intent intent = getIntent();
        if(intent.hasExtra(KEY_EVENT_ID)) {
            eventId = intent.getLongExtra(KEY_EVENT_ID, -1);
            populateEventDetails(eventId);
        }

        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveEvent();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddEventActivity.this, EventListActivity.class);
                startActivity(intent);
            }
        });
    }

    private void populateEventDetails(long eventId) {
        Cursor cursor = null;
        try {
            cursor = eventDatabase.getEventById(eventId);

            if (cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow("id"));

                    if (id == eventId) {
                        String eventName = cursor.getString(cursor.getColumnIndexOrThrow("eventName"));
                        String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                        String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));

                        editTextEventName.setText(eventName);
                        editTextEventDate.setText(date);
                        editTextEventDescription.setText(description);
                        break;
                    }
                } while (cursor.moveToNext());
            }
        }
        finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private void saveEvent() {
        String eventName = editTextEventName.getText().toString().trim();
        String date = editTextEventDate.getText().toString().trim();
        String description = editTextEventDescription.getText().toString().trim();

        if (!eventName.isEmpty()) {
            if (eventId != -1) {
                int result = eventDatabase.editEvent((int) eventId, eventName, date, description);
                if (result > 0) {
                    Toast.makeText(this, "Event changed successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Failed to change event", Toast.LENGTH_SHORT).show();
                }
            }
            else {
                long result = eventDatabase.insertEvent(eventName, date, description);
                if (result != -1) {
                    Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Failed to add event", Toast.LENGTH_SHORT).show();
                }
            }
            finish();
        }
        else {
            Toast.makeText(this, "Must enter event name", Toast.LENGTH_SHORT).show();
        }
    }
}