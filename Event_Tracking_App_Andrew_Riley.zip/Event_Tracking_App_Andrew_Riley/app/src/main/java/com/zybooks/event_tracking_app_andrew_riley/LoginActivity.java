package com.zybooks.event_tracking_app_andrew_riley;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton, newUserButton;
    private EventDatabase eventDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        newUserButton = findViewById(R.id.newUserButton);
        eventDatabase = new EventDatabase(this);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });
        newUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addNewUser();
            }
        });
    }

    private void addNewUser() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (!username.isEmpty() && !password.isEmpty()) {
            long result = eventDatabase.insertUserData(username, password);

            if (result != -1) {
                Toast.makeText(this, "User successfully added", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "User not added", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "Username and password required", Toast.LENGTH_SHORT).show();
        }
    }

    private void login() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (!username.isEmpty() && !password.isEmpty()) {
            if (eventDatabase.checkUser(username, password)) {
                Intent intent = new Intent(this, EventListActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(this, "Login failed. Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this, "Username and password required", Toast.LENGTH_SHORT).show();
        }
    }
}